import java.io.File;

import com.github.javaparser.JavaParser;

public class SequenceParser {

	
private static void parseJava(String source, String outputFileName) {
		
		// TODO Auto-generated method stub
		
	}
}
